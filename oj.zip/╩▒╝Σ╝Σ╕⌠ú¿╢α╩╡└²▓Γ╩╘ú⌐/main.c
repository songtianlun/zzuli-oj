#include <stdio.h>
#include <stdlib.h>
int HmsToS(int h, int m, int s);
void PrintTime(int s);

int main()
{
    int h1,m1,s1,h2,m2,s2;
    while(scanf("%d:%d:%d",&h1,&m1,&s1),scanf("%d:%d:%d",&h2,&m2,&s2)!=EOF)
    {

    }
    printf("Hello world!\n");
    return 0;
}
