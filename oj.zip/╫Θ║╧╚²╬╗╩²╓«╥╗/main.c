#include<stdio.h>
int main()
{
    printf("361 529 784\n");
    return 0;
}
