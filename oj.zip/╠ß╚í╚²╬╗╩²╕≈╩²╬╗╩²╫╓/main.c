#include <stdio.h>
#include <stdlib.h>

int main()
{
    int h,t,z;

    scanf("%1d%1d%d",&h,&t,&z);
    printf("%d %d %d\n", z, t, h);
    return 0;
}
