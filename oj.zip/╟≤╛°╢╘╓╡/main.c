#include <stdio.h>
#include <stdlib.h>

int main()
{
    double m;

    scanf("%lf",&m);
    printf("%.2f\n",fabs(m));
    return 0;
}
