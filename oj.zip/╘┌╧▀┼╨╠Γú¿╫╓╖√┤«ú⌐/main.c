#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i,n,t;
    char a[100000],b[100000];
    scanf("%d",&t);
    while(t--)
    {
        scanf("START\n%s\nEND",a);
        scanf("START\n%s\nEND",b);
    }
    printf("Hello world!\n");
    return 0;
}
