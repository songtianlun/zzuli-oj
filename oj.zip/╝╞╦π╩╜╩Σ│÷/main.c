#include <stdio.h>
#include <stdlib.h>

int main()
{
    int y, x;

     scanf("%d", &x);
     y=2*x*x+x+8;
    printf("%d\n",y);
    return 0;
}
