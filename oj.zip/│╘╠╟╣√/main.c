#include <stdio.h>
#include <stdlib.h>

int main()
{
    int T,N,Mi[999999],i;
    scanf("%d",&T);
    while(T>0)
    {
        scanf("%d",&N);
        for(i=0;i<N;i++)
        {

        }
        T--;
    }
    return 0;
}
